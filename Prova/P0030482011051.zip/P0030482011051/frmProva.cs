﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P0030482011051
{
    public partial class frmProva : Form
    {
        public frmProva()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[1, 4];
            lstValores.Items.Clear();
            bool aux;
            double resultadoMes = 0;
            double resultadoFinal = 0;
            for (int i = 0; i < 1; i++)
            {
                resultadoMes = 0;
                for (int j = 0; j < 4; j++)
                {
                    do
                    {
                        aux = double.TryParse(Interaction.InputBox("Digite o Número " + (j + 1), "Digite os números"), out matriz[i,j]);
                    } while (aux == false);
                    lstValores.Items.Add("Total do Mês:" + (i + 1) + " Semana " + (j+1)+" " + matriz[i,j].ToString("C2"));
                    resultadoMes += matriz[i,j];
                }
                lstValores.Items.Add(">>Total do Mês: " + resultadoMes.ToString("C2"));
                lstValores.Items.Add("--------------------------\n");
                resultadoFinal += resultadoMes;
            }
            lstValores.Items.Add(">>Total Geral: " + resultadoFinal.ToString("C2"));
        }
    }
}
