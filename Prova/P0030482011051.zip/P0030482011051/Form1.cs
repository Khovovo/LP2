﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P0030482011051
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            lstValores.Items.Clear();
            int finalRa = 1;
            bool aux;
            double[] num = new double[4];
            double resultadoMes = 0;
            double resultadoFinal = 0;
            for (int i = 0; i < finalRa; i++)
            {
                resultadoMes = 0;
                for (int j = 0; j < 4; j++)
                {
                    do
                    {
                        aux = double.TryParse(Interaction.InputBox("Digite o Número " + (j + 1), "Digite os números"), out num[j]);
                    } while (aux == false);
                    lstValores.Items.Add("Total do Mês:" + (i + 1) + " Semana " + (j+1) + num[j].ToString("C2"));
                    resultadoMes += num[j];
                }
                lstValores.Items.Add(">>Total do Mês: " + resultadoMes.ToString("C2"));
                lstValores.Items.Add("--------------------------\n");
                resultadoFinal += resultadoMes;
            }
            lstValores.Items.Add(">>Total Geral: " + resultadoFinal.ToString("C2"));
        }
    }
}
